angular.module('app.controllers', [])
     
.controller('entrainementCtrl', function($scope) {

})
   
.controller('historiqueCtrl', function($scope) {

})
   
.controller('paramTresCtrl', function($scope) {

})
      
.controller('informationsEtStatistiquesCtrl', function($scope) {

})
   
.controller('chronomTreCtrl', function($scope) {

})
   
.controller('aProposDeNousCtrl', function($scope) {

})
 